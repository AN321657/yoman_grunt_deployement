module.exports = 2 + require('./a').a
