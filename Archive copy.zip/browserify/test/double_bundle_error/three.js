require('./nosuchfile.js');

module.exports = 3;
