var EventEmitter = require('events').EventEmitter
var ee = new EventEmitter;
ee.setMaxListeners(5);
