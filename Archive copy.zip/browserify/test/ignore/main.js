t.deepEqual(require('./skip.js'), {});
