#!/blah
module.exports = 1234;
