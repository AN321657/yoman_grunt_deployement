module.exports = {
    a: true,
    b: require('./b')
};
