ex(require('./evil-chars.json'));
ex(require('./evil-chars'));
