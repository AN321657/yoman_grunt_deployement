console.log(FFF * GGG * HHH);
