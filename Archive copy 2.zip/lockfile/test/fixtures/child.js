var lockFile = require('../../lockfile.js')

lockFile.lock('never-forget', function () {})
